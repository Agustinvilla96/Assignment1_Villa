package calculator_villa;
import java.util.Scanner;
import java.lang.Math;

public class calculator {

	public static void main(String[] args) {
		
		Scanner scanner = new Scanner(System.in);
		double number1;
		double number2;
		char operator;
		double awnser = 0;
		int pick;
		
		
		System.out.println("Would you like to use a 1) Basic Calculator or 2)Operand Calulator");
		pick = scanner.nextInt();
		
		if (pick == 1 )
		{
		
			System.out.println("This Calculator Only Takes 2 Digits and an Operand \nYou Will be asked to Enter these Individually \n");
		
		
		
			System.out.println("Please Enter the first Digit:  ");
			number1 = scanner.nextDouble();
			System.out.println("");
		
		
			System.out.println("Please Enter the Second Digit: ");
			number2 = scanner.nextDouble();
			System.out.println("");
		
			System.out.println("Enter the opperand you'd like \n Example (+, -, *, /): ");
			operator = scanner.next().charAt(0);
		
			scanner.close();
		
		
				switch(operator)
				{
					case '+':
						awnser = number1 + number2;
						break;
		
					case '-':
						awnser = number1 - number2;
						break;
			
					case '*':
						awnser = number1 * number2;
						break;
		
					case '/':
						awnser = number1 / number2;
						break;
			
			
					default: 
						System.out.println("Operand Not Found: ");
						return;
				
		
				}
		}
		
				
			if (pick == 2 )
				
				{
					
					int pickem;
					
					System.out.println("Operand Calculator will allow you to get 1)sqaure root, 2)Power and 3)Factorial: ");
					pickem = scanner.nextInt();
					
					if (pickem==1)
					{
						System.out.println("Please Enter Number you'd like to sqaure root: ");
						number1 = scanner.nextDouble();
						
						awnser = (Math.sqrt(number1));
						
						System.out.println(awnser);
						
					}
					
					if (pickem==2)
					{
						System.out.println("Please Enter the Base: ");
						number1 = scanner.nextDouble();
						
						System.out.println("Please Enter the Exponent: ");
						number2 = scanner.nextDouble();
						
						awnser = (Math.pow(number1, number2));
						System.out.println(awnser);
					}
					
					if (pickem==3)
					{
						int factorial = 0;
						System.out.println("Enter an Integer to find it's factorial");
						number1 = scanner.nextDouble();
						
						
						if (number1<0)
						{
							System.out.println("Number is Negative Please try again");
							
						}
						
						else 
						{
							for (int x =1; x<=number1; x++)
							{
							
								factorial = factorial * x;
							}
								
							
							System.out.println(factorial);
						}
						
					
					}
					
					
					
				}
	System.out.println(awnser);
		
		
		
		
		
		
		
		
		
		
		
	}


}
