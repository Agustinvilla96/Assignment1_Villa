package shapes;
import java.util.Scanner;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Scanner scanner = new Scanner (System.in);
		
		int pick;
		double radius;
		double awnser;
		double base;
		double height;
		double length;
		double breadth;
		
		System.out.println("Enter the Shape you'd Like to Calculate the area for: ");
		System.out.println("1)Circle 2)Triangle 3) Rectangle 4)Sqaure 5)Cube");
		
		pick = scanner.nextInt();
		
		
		switch(pick) {
		
		case '1':
			System.out.println("Enter the radius");
			radius = scanner.nextDouble();
			awnser = Math.PI * (radius * radius);
			System.out.println(awnser);
		case '2':
			System.out.println("Enter Base: ");
			base = scanner.nextDouble();
			System.out.println("Enter Height: ");
			height = scanner.nextDouble();
			awnser = (base*height)/2;
		case '3':
			System.out.println("Enter the length: ");
			length = scanner.nextDouble();
			System.out.println("Enter Breadth: ");
			breadth = scanner.nextDouble();
			awnser = length*breadth;
			System.out.println(awnser);
		case '4':
			System.out.println("Enter Side of Sqaure: ");
			double side = scanner.nextDouble();
			System.out.println(side*side);
		case '5':
			System.out.println("Enter Side of Sqaure: ");
			double sides = scanner.nextDouble();
			System.out.println(6* sides*sides);
			
			
			
			
			
			
			
		
				
			
			
		
		}
		
		
		

	}

}
